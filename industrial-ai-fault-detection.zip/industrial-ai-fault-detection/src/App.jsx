import React, { useEffect, useMemo, useState } from 'react';
import { Activity, AlertTriangle, Bolt, Gauge, Thermometer, Waves, RotateCw, ShieldCheck, CircleHelp, Factory, RefreshCw, Download, Radio, Zap } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar } from 'recharts';

const initial = {temperature:64.2, vibration:2.4, current:8.6, rpm:1460};
const clamp=(n,min,max)=>Math.max(min,Math.min(max,n));
function makeReading(prev) {
  return {
    temperature:+clamp(prev.temperature+(Math.random()-.48)*2.6,42,104).toFixed(1),
    vibration:+clamp(prev.vibration+(Math.random()-.5)*.42,0.4,8.5).toFixed(2),
    current:+clamp(prev.current+(Math.random()-.5)*.5,3,18).toFixed(2),
    rpm:Math.round(clamp(prev.rpm+(Math.random()-.5)*36,900,1800))
  };
}
function statusFor(r) {
  if(r.temperature>=85 || r.vibration>=5.5 || r.current>=14 || r.rpm<1100) return {label:'Critical', tone:'red', message:'Stop and inspect motor; readings exceed safe demo thresholds.'};
  if(r.temperature>=75 || r.vibration>=3.8 || r.current>=11.5 || r.rpm<1300) return {label:'Warning', tone:'amber', message:'Abnormal pattern detected. Schedule a maintenance inspection.'};
  return {label:'Normal',tone:'green',message:'All simulated sensor readings are within configured demo thresholds.'};
}
export default function App(){
 const [reading,setReading]=useState(initial);
 const [running,setRunning]=useState(true);
 const [history,setHistory]=useState([{time:new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}),...initial,energy:2.1}]);
 const [limit,setLimit]=useState(75);
 useEffect(()=>{if(!running)return; const id=setInterval(()=>setReading(prev=>{const next=makeReading(prev);setHistory(h=>[...h.slice(-19),{time:new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}),...next,energy:+(next.current*0.23).toFixed(2)}]);return next;}),2500);return()=>clearInterval(id)},[running]);
 const status=statusFor(reading);
 const energy=+(reading.current*0.23).toFixed(2);
 const faults=useMemo(()=>[
   {name:'Temperature',value:reading.temperature,unit:'°C',threshold:85,ok:reading.temperature<75},
   {name:'Vibration RMS',value:reading.vibration,unit:'mm/s',threshold:5.5,ok:reading.vibration<3.8},
   {name:'Motor current',value:reading.current,unit:'A',threshold:14,ok:reading.current<11.5},
   {name:'Motor speed',value:reading.rpm,unit:'RPM',threshold:1100,ok:reading.rpm>=1300}
 ],[reading]);
 const downloadReport=()=>{const rows=[['time','temperature_C','vibration_mm_s','current_A','rpm','estimated_kW'],...history.map(h=>[h.time,h.temperature,h.vibration,h.current,h.rpm,h.energy])];const csv=rows.map(r=>r.join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download='motor-sensor-history.csv';a.click();URL.revokeObjectURL(a.href)};
 return <div className="app-shell">
  <aside className="sidebar">
   <div className="brand"><div className="brand-icon"><Factory size={22}/></div><div><b>INDUSTRIAL AI</b><span>Motor intelligence</span></div></div>
   <div className="nav-label">WORKSPACE</div><div className="nav active"><Activity size={17}/> Overview</div><div className="nav"><Waves size={17}/> Sensor analytics</div><div className="nav"><ShieldCheck size={17}/> Predictive maintenance</div><div className="nav"><Zap size={17}/> Energy optimization</div>
   <div className="side-bottom"><div className="connection"><span className="dot"></span><div><b>Demo simulator</b><small>Local sensor stream</small></div></div><p>Prototype build · v1.0</p></div>
  </aside>
  <main className="main">
   <header className="topbar"><div><div className="eyebrow">MONITORING / ASSET 01</div><h1>Motor intelligence dashboard</h1><p className="subhead">Sensor-based fault detection and energy optimization</p></div><div className="top-actions"><span className="demo-pill"><span className="dot"></span> SIMULATED DATA</span><button className="button secondary" onClick={downloadReport}><Download size={16}/> Export CSV</button><button className="button primary" onClick={()=>setRunning(!running)}>{running?<><span className="pause">Ⅱ</span> Pause stream</>:<><RefreshCw size={15}/> Resume stream</>}</button></div></header>
   <section className="asset-banner"><div className="asset-visual"><div className="motor"><div className="motor-cap"></div><div className="motor-body"><div className="motor-ribs"></div><div className="motor-label">INDUCTION<br/>MOTOR</div></div><div className="motor-shaft"></div><div className="motor-base"></div></div></div><div className="asset-info"><span className="tag">ASSET · IM-001</span><h2>Industrial induction motor</h2><p>Production line drive · 3-phase AC motor</p><div className="asset-meta"><span><i className="green-dot"></i> {running?'Monitoring active':'Stream paused'}</span><span><Radio size={14}/> 4 sensor channels</span><span><CircleHelp size={14}/> Demo profile</span></div></div><div className="health-box"><span>OVERALL CONDITION</span><strong className={status.tone}>{status.label}</strong><small>Rule-based threshold model</small></div></section>
   <section className="metric-grid">
    <Metric icon={<Thermometer/>} title="Temperature" value={reading.temperature} unit="°C" note="Motor casing" tone={reading.temperature>=85?'red':reading.temperature>=75?'amber':'blue'} />
    <Metric icon={<Waves/>} title="Vibration RMS" value={reading.vibration} unit="mm/s" note="Bearing condition proxy" tone={reading.vibration>=5.5?'red':reading.vibration>=3.8?'amber':'purple'} />
    <Metric icon={<Bolt/>} title="Motor current" value={reading.current} unit="A" note="Current sensor channel" tone={reading.current>=14?'red':reading.current>=11.5?'amber':'amber'} />
    <Metric icon={<Gauge/>} title="Motor speed" value={reading.rpm} unit="RPM" note="Optical RPM estimate" tone={reading.rpm<1100?'red':reading.rpm<1300?'amber':'green'} />
   </section>
   <section className="content-grid">
    <div className="panel chart-panel"><div className="panel-head"><div><h3>Live sensor trends</h3><p>Latest 20 simulator samples</p></div><span className="live"><span className="dot"></span> LIVE</span></div><div className="chart-legend"><span><i className="legend blue-bg"></i> Temperature (°C)</span><span><i className="legend purple-bg"></i> Vibration (mm/s)</span></div><ResponsiveContainer width="100%" height={245}><AreaChart data={history}><defs><linearGradient id="tempFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#4f8cff" stopOpacity={0.22}/><stop offset="100%" stopColor="#4f8cff" stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" stroke="#202d40"/><XAxis dataKey="time" tick={{fill:'#7f8da3',fontSize:10}} tickLine={false} axisLine={false}/><YAxis yAxisId="temp" tick={{fill:'#7f8da3',fontSize:10}} tickLine={false} axisLine={false} width={30}/><Tooltip contentStyle={{background:'#111c2d',border:'1px solid #2b3a50',borderRadius:10,color:'#e9eff8'}}/><Area yAxisId="temp" type="monotone" dataKey="temperature" name="Temperature °C" stroke="#4f8cff" fill="url(#tempFill)" strokeWidth={2} isAnimationActive={false}/><Area yAxisId="temp" type="monotone" dataKey="vibration" name="Vibration mm/s" stroke="#a78bfa" fill="transparent" strokeWidth={2} isAnimationActive={false}/></AreaChart></ResponsiveContainer></div>
    <div className="panel"><div className="panel-head"><div><h3>Fault detection</h3><p>Threshold-based anomaly screening</p></div><AlertTriangle size={18} className="muted-icon"/></div><div className="fault-list">{faults.map(f=><div className="fault-row" key={f.name}><div className="fault-status">{f.ok?<ShieldCheck size={17}/>:<AlertTriangle size={17}/>}</div><div className="fault-main"><b>{f.name}</b><small>Threshold: {f.threshold} {f.unit}</small></div><strong className={f.ok?'good-text':'warn-text'}>{f.value} {f.unit}</strong></div>)}</div><div className={'alert-box '+status.tone}><AlertTriangle size={17}/><div><b>{status.label} assessment</b><p>{status.message}</p></div></div></div>
   </section>
   <section className="content-grid bottom-grid">
    <div className="panel"><div className="panel-head"><div><h3>Energy optimization</h3><p>Estimated indicator from demo current data</p></div><Zap size={18} className="muted-icon"/></div><div className="energy-summary"><div><span>Estimated power indicator</span><strong>{energy} <small>kW*</small></strong></div><div className="energy-badge"><Bolt size={17}/> Monitoring</div></div><div className="slider-label"><span>Target energy indicator</span><b>{limit} kW</b></div><input aria-label="Target energy indicator" type="range" min="40" max="120" value={limit} onChange={e=>setLimit(+e.target.value)}/><div className="recommendation"><div className="recommend-icon"><Zap size={17}/></div><div><b>{energy>limit?'Review load and operating conditions':'Maintain efficient operating range'}</b><p>{energy>limit?'The demo indicator exceeds your configured target. Inspect load, bearing friction, and supply conditions.':'Keep monitoring load and temperature trends; compare with verified nameplate and power-meter readings.'}</p></div></div><small className="footnote">*Illustrative estimate only; current × 0.23 is not a validated real power measurement.</small></div>
    <div className="panel"><div className="panel-head"><div><h3>System readiness</h3><p>Prototype integration checklist</p></div><span className="tag">PHASE 1</span></div><div className="checklist"><Check title="Dashboard UI" state="Ready" good/><Check title="Simulated sensor stream" state={running?'Running':'Paused'} good={running}/><Check title="Rule-based fault screening" state="Demo" /><Check title="ESP32 / MQTT integration" state="Pending"/><Check title="Trained ML model validation" state="Pending"/></div><div className="integration-note"><CircleHelp size={16}/><p>Do not use this demo for safety-critical decisions. Validate sensor calibration and thresholds before connecting to industrial equipment.</p></div></div>
   </section>
   <footer>INDUSTRIAL AI · CSE MAJOR PROJECT <span>Simulation mode · No physical motor connected</span></footer>
  </main>
 </div>
}
function Metric({icon,title,value,unit,note,tone}){return <div className="metric-card"><div className={'metric-icon '+tone}>{icon}</div><div className="metric-label">{title}</div><div className="metric-value">{value}<small>{unit}</small></div><div className="metric-note">{note}</div><div className="metric-spark"><span className={tone}></span><span className={tone}></span><span className={tone}></span><span className={tone}></span><span className={tone}></span><span className={tone}></span><span className={tone}></span><span className={tone}></span><span className={tone}></span><span className={tone}></span><span className={tone}></span><span className={tone}></span></div></div>}
function Check({title,state,good=false}){return <div className="check-row"><span className={'check-mark '+(good?'checked':'')}>{good?'✓':'•'}</span><span>{title}</span><small>{state}</small></div>}
