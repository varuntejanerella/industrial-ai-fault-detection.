# Industrial AI Fault Detection & Energy Optimization

A CSE major-project prototype for monitoring industrial motor sensor data, flagging abnormal readings, and displaying energy-use indicators.

## Current features

- Responsive industrial motor monitoring dashboard
- Simulated temperature, vibration, current, and RPM readings that update every 2.5 seconds
- Configurable demo thresholds and rule-based Normal / Warning / Critical assessment
- Sensor trend chart and CSV export of recent simulated samples
- Energy indicator and target slider with recommendations
- Hardware and model integration checklist

## Important limitations

This repository currently uses **simulated sensor data**. The rule-based checks are a demonstration, not a trained machine-learning model or a certified predictive-maintenance system. The displayed power figure is a rough illustrative indicator (`current × 0.23`) and is **not** a validated power measurement. Do not use this app for safety-critical decisions or to control industrial equipment.

## Requirements

- Node.js 18+ (Node.js 20+ recommended)
- npm

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite, usually `http://localhost:5173`.

## Production build

```bash
npm run build
npm run preview
```

## Project structure

```text
industrial-ai-fault-detection/
├── index.html
├── package.json
├── README.md
└── src/
    ├── main.jsx
    ├── App.jsx
    └── style.css
```

## Suggested development roadmap

1. **Sensor hardware:** Connect temperature, vibration, current, and RPM sensors to an ESP32. Confirm voltage/current isolation and sensor specifications before wiring.
2. **Data transport:** Send timestamped readings through MQTT or a secured HTTP API; validate payloads and reject malformed values.
3. **Backend and persistence:** Add a Python FastAPI service and PostgreSQL/SQLite storage for telemetry, alerts, assets, and maintenance events.
4. **ML fault detection:** Train and evaluate anomaly detection on a documented dataset. Split evaluation by machine/time to avoid leakage; report precision, recall, F1, false-alarm rate, and lead time.
5. **Energy estimation:** Use a calibrated power meter or suitable three-phase energy meter. Do not estimate industrial real power from current alone.
6. **Security and deployment:** Add authentication, TLS, role-based access, input validation, audit logs, and environment-based secrets.

## GitHub upload

Create an empty repository named `industrial-ai-fault-detection`, then run these commands from this folder:

```bash
git init
git add .
git commit -m "Initial industrial AI monitoring dashboard"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/industrial-ai-fault-detection.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Never commit tokens, passwords, or `.env` files.
